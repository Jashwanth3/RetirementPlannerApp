﻿using System.Data;

namespace backend.Data
{
    public interface IDatabase
    {
        IDbConnection CreateConnection();
    }
}
