﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;

namespace backend.Data
{
    public class MySqlDatabase : IDatabase
    {
        private readonly IConfiguration _config;
        private readonly string _connectionString;

        public MySqlDatabase(IConfiguration config)
        {

            _config = config;
            _connectionString = _config.GetConnectionString("DefaultConnection") 
                                ?? "server=localhost;port=3306;database=RetirementPlannerDb;user=root;password=Root@39";

        }

        public IDbConnection CreateConnection()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_connectionString))
                {
                    Console.WriteLine("Error: Connection string is invalid.");
                    return new MySqlConnection(); 
                }

                return new MySqlConnection(_connectionString);
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Database Connection Error: {ex.Message}");
                throw; 
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected Error: {ex.Message}");
                throw;
            }
        }
    }
}
