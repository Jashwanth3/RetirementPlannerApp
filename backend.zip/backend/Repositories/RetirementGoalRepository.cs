﻿using System.Data;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using backend.Data;
using Microsoft.Extensions.Logging;

namespace backend.Repositories
{
    public class RetirementGoalRepository : IRetirementGoalRepository
    {
        private readonly IDatabase _database;
        private readonly ILogger<RetirementGoalRepository> _logger;

        public RetirementGoalRepository(IDatabase database, ILogger<RetirementGoalRepository> logger)
        {
            _database = database;
            _logger = logger;
        }

         public async Task<RetirementGoal?> AddGoalAsync(RetirementGoal goal)
{
    RetirementGoal newGoal = null;

    using var db = (MySqlConnection)_database.CreateConnection();
    try
    {
        await db.OpenAsync();
        using var cmd = new MySqlCommand("AddRetirementGoals", db) { CommandType = CommandType.StoredProcedure };

        cmd.Parameters.AddWithValue("p_UserId", goal.UserId);
        cmd.Parameters.AddWithValue("p_DesiredSavings", goal.DesiredSavings);
        cmd.Parameters.AddWithValue("p_RetirementAge", goal.RetirementAge);
        cmd.Parameters.AddWithValue("p_CurrSavings", goal.CurrSavings);

        var idParam = new MySqlParameter("p_Id", MySqlDbType.Int32) { Direction = ParameterDirection.Output };
        cmd.Parameters.Add(idParam);

        await cmd.ExecuteNonQueryAsync();

        var insertedGoalId = Convert.ToInt32(idParam.Value);
        
        // Fetch the inserted goal details
        using var fetchCmd = new MySqlCommand("SELECT Id, UserId, DesiredSavings, RetirementAge, CurrSavings, RecommendedValue FROM retirementgoals WHERE Id = @Id", db);
        fetchCmd.Parameters.AddWithValue("@Id", insertedGoalId);

        using var reader = await fetchCmd.ExecuteReaderAsync();
        if (await reader.ReadAsync())
        {
            newGoal = new RetirementGoal
            {
                Id = reader.GetInt32("Id"),
                UserId = reader.GetInt32("UserId"),
                DesiredSavings = reader.GetDecimal("DesiredSavings"),
                RetirementAge = reader.GetInt32("RetirementAge"),
                CurrSavings = reader.GetDecimal("CurrSavings"),
                RecommendedValue = reader.GetDecimal("RecommendedValue")
            };
        }
    }
    catch (MySqlException ex)
    {
        _logger.LogError(ex, "Error adding retirement goal.");
    }

    return newGoal;
}









        public async Task<IEnumerable<RetirementGoal>> GetGoalsByUserIdAsync(int userId)
        {
            var retirementGoals = new List<RetirementGoal>();
            using var db = (MySqlConnection)_database.CreateConnection();
            try
            {
                await db.OpenAsync();
                using var cmd = new MySqlCommand("GetRetirementGoalsByUserId", db) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("p_UserId", userId);
                
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    retirementGoals.Add(new RetirementGoal
                    {
                        Id = reader.GetInt32("Id"),  
                        UserId = reader.GetInt32("UserId"),
                        DesiredSavings = reader.GetDecimal("DesiredSavings"),
                        RetirementAge = reader.GetInt32("RetirementAge"),
                        CurrSavings = reader.GetDecimal("CurrSavings"),
                        RecommendedValue = reader.GetDecimal("RecommendedValue"),
                    });
                }
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving retirement goals by user ID.");
            }
            return retirementGoals;
        }
    }
}