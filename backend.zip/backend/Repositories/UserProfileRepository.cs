﻿using System.Data;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using backend.Data;
using Microsoft.Extensions.Logging;

namespace backend.Repositories
{
    public class UserProfileRepository : IUserProfileRepository
    {
        private readonly IDatabase _database;
        private readonly ILogger<UserProfileRepository> _logger;

        public UserProfileRepository(IDatabase database, ILogger<UserProfileRepository> logger)
        {
            _database = database;
            _logger = logger;
        }


        public async Task AddAsync(UserProfile user)
        {
            using var db = (MySqlConnection)_database.CreateConnection();
            try
            {
                await db.OpenAsync();
                using var cmd = new MySqlCommand("AddUserProfile", db) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("p_firstname", user.FirstName);
                cmd.Parameters.AddWithValue("p_lastname", user.LastName);
                cmd.Parameters.AddWithValue("p_username", user.UserName);
                cmd.Parameters.AddWithValue("p_currage", user.CurrAge);
                cmd.Parameters.AddWithValue("p_email", user.Email);
                cmd.Parameters.AddWithValue("p_password", user.Password);
                await cmd.ExecuteNonQueryAsync();
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "An error occurred while adding user profile.");
            }
        }

        public async Task<UserProfile?> LoginAsync(string email, string password)
        {
            UserProfile userProfile = null;
            using var db = (MySqlConnection)_database.CreateConnection();
            try
            {
                await db.OpenAsync();
                using var cmd = new MySqlCommand("LoginUser", db) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("inputEmail", email);
                cmd.Parameters.AddWithValue("inputPassword", password);
                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    userProfile = new UserProfile
                    {
                        Id = reader.GetInt32("Id"),
                        FirstName = reader.GetString("FirstName"),
                        LastName = reader.GetString("LastName"),
                        UserName = reader.GetString("UserName"),
                        CurrAge = reader.GetInt32("CurrAge"),
                        Email = reader.GetString("Email")
                    };
                }
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "An error occurred while logging in user.");
            }

            return userProfile; 
        }
    }
}
