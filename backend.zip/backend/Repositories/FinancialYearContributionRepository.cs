﻿using System.Data;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using backend.Data;
using Microsoft.Extensions.Logging;

namespace backend.Repositories
{
    public class FinancialYearContributionRepository : IFinancialYearContributionRepository
    {
        private readonly IDatabase _database;
        private readonly ILogger<FinancialYearContributionRepository> _logger;

        public FinancialYearContributionRepository(IDatabase database, ILogger<FinancialYearContributionRepository> logger)
        {
            _database = database;
            _logger = logger;
        }

        public async Task AddContributionAsync(FinancialYearContribution contribution)
        {
            using var db = (MySqlConnection)_database.CreateConnection();
            try
            {
                await db.OpenAsync();
                using var cmd = new MySqlCommand("AddFinancialYearContributions", db) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("p_GoalId", contribution.GoalId);
                cmd.Parameters.AddWithValue("p_ContributionMonth", contribution.ContributionMonth);
                cmd.Parameters.AddWithValue("p_ContributionYear", contribution.ContributionYear);
                cmd.Parameters.AddWithValue("p_ContributionAmount", contribution.ContributionAmount);
                
                await cmd.ExecuteNonQueryAsync();
            }
            catch (MySqlException ex)
            {
                // Detect the custom SQLSTATE error from your stored procedure
                if (ex.Number == 1644 || ex.Message.Contains("Duplicate entry: A contribution for this month already exists!"))
                {
                    _logger.LogWarning("Duplicate entry detected: A contribution for this month already exists.");
                    throw new InvalidOperationException("A contribution for this month already exists!"); 
                }

                _logger.LogError(ex, "An error occurred while adding financial year contribution.");
                throw; // Ensure unexpected errors still propagate
            }
        }



        public async Task<IEnumerable<FinancialYearContribution>> GetContributionByIdAsync(int id)
        {
            var contributions = new List<FinancialYearContribution>(); 
            using var db = (MySqlConnection)_database.CreateConnection();
            try
            {
                await db.OpenAsync();
                using var cmd = new MySqlCommand("GetFinancialYearContributionById", db) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("p_GoalId", id);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync()) 
                {
                    contributions.Add(new FinancialYearContribution
                    {
                        GoalId = reader.GetInt32("GoalId"),
                        ContributionMonth = reader.GetInt32("ContributionMonth"),
                        ContributionYear = reader.GetInt32("ContributionYear"),
                        ContributionAmount = reader.GetDecimal("ContributionAmount")
                    });
                }
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving financial year contributions by ID.");
            }
            return contributions;
        }

    }
}
