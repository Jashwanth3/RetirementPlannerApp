using System.Data;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using backend.Data;
using Microsoft.Extensions.Logging;

namespace backend.Repositories
{
    public class UserProgressRepository : IUserProgressRepository
    {
        private readonly IDatabase _database;
        private readonly ILogger<UserProgressRepository> _logger;

        public UserProgressRepository(IDatabase database, ILogger<UserProgressRepository> logger)
        {
            _database = database;
            _logger = logger;
        }

        
        public async Task<IEnumerable<UserProgress>> GetUserProgressByGoalIdAsync(int GoalId)
        {
            var userProgress = new List<UserProgress>();
            using var db = (MySqlConnection)_database.CreateConnection();
            try
            {
                await db.OpenAsync();
                using var cmd = new MySqlCommand("GetUserProgressByGoalId", db) { CommandType = CommandType.StoredProcedure };
                cmd.Parameters.AddWithValue("p_GoalId", GoalId);
                
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    userProgress.Add(new UserProgress
                    {
                        Id = reader.GetInt32("Id"),  
                        GoalId = reader.GetInt32("GoalId"),
                        TotalContributed = reader.GetDecimal("TotalContributed")
                    });
                }
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving progress by goal ID.");
            }
            return userProgress;
        }
    }
}