﻿namespace backend.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class FinancialYearContribution
{
    [Key]
    public int Id { get; set; }

    [ForeignKey("RetirementGoal")]
    public int GoalId { get; set; } 

    public int ContributionMonth {get; set;}

    public int ContributionYear {get; set;}

    public decimal ContributionAmount { get; set; }


}
