namespace backend.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class UserProgress{

    [Key]
    public int Id { get; set; }

    [Required]
    [ForeignKey("RetirementGoal")]
    public int GoalId { get; set; }

    public decimal TotalContributed { get; set; }

}