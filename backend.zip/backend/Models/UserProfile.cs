﻿namespace backend.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class UserProfile
{
    [Key]
    public int Id { get; set; }

    [Required, MaxLength(20)]
    public string FirstName { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string LastName { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string UserName { get; set; } = string.Empty;

    [Required]
    public int CurrAge { get; set; }

    [Required, EmailAddress, MaxLength(50)]
    public string? Email {get; set;}

    [Required, MaxLength(20)]
    public string? Password { get; set; } = string.Empty;

}
