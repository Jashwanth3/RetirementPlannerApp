﻿namespace backend.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


public class RetirementGoal
{
    [Key]
    public int Id {get; set;}

    [Required]
    [ForeignKey("UserProfile")]
    public int UserId { get; set; }

    [Required]
    public decimal DesiredSavings {get; set;}

    [Required]
    public int RetirementAge {get; set;}

    [Required]
    public decimal CurrSavings {get; set;}

    public decimal RecommendedValue {get; set;}

}
