using backend.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.Data;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using Dapper;

namespace backend.Services;

public interface IUserProgressService
{
    Task<IEnumerable<UserProgress>> GetUserProgressByGoalIdAsync(int GoalId);
}
