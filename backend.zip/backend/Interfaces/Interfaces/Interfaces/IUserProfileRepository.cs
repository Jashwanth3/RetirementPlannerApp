﻿using backend.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.Data;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;


namespace backend.Repositories;

public interface IUserProfileRepository
{
    Task AddAsync(UserProfile userProfile);
    Task<UserProfile?> LoginAsync(string email, string password);

}
