using Dapper;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using backend.Models;
using System.Collections.Generic;

namespace backend.Services{
public interface IUserProfileService
{
    Task AddAsync(UserProfile userProfile);
    Task<UserProfile?> LoginAsync(string email, string password);
}
}