﻿using backend.Models;
using backend.Data;
using System.Data;
using Dapper;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using backend.Repositories;
using System.Linq;

namespace backend.Services;

public interface IFinancialYearContributionService
{
    Task<IEnumerable<FinancialYearContribution>> GetContributionByIdAsync(int id);
    Task AddContributionAsync(FinancialYearContribution contribution);
}
