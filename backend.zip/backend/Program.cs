using backend.Data;
using backend.Models;
using backend.Services;
using backend.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.OpenApi.Models;



var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo 
    { 
        Title = "Retirement Planner API", 
        Version = "v1"
    });
});


//MySql connection
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");



builder.Services.AddScoped<IDatabase, MySqlDatabase>();

//UserProfileService
builder.Services.AddScoped<IUserProfileService, UserProfileService>();
builder.Services.AddScoped<IUserProfileRepository, UserProfileRepository>();
//RetirementGoalService
builder.Services.AddScoped<IRetirementGoalService,RetirementGoalService>();
builder.Services.AddScoped<IRetirementGoalRepository, RetirementGoalRepository>();
//FinancialYearContributionService
builder.Services.AddScoped<IFinancialYearContributionService, FinancialYearContributionService>();
builder.Services.AddScoped<IFinancialYearContributionRepository, FinancialYearContributionRepository>();
//UserProgressService
builder.Services.AddScoped<IUserProgressService,UserProgressService>();
builder.Services.AddScoped<IUserProgressRepository,UserProgressRepository>();

//Add Services to the container.
builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        builder => builder.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader());
});



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "Retirement Planner API v1");
        c.RoutePrefix = string.Empty;
    });

}


app.UseCors("AllowAll");
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
