using Dapper;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using System.Linq;
using backend.Repositories;

namespace backend.Services;

public class UserProgressService : IUserProgressService
{
    private readonly IConfiguration _config;
    private readonly IUserProgressRepository _userProgressRepository;

    public UserProgressService(IConfiguration config, IUserProgressRepository userProgressRepository)
    {
        _config = config;
        _userProgressRepository = userProgressRepository;
    }

    
    public async Task<IEnumerable<UserProgress>> GetUserProgressByGoalIdAsync(int GoalId)
    {
        return await _userProgressRepository.GetUserProgressByGoalIdAsync(GoalId);
    }
}
