﻿using Dapper;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using System.Linq;
using backend.Repositories;

namespace backend.Services;

public class FinancialYearContributionService : IFinancialYearContributionService
{
    private readonly IConfiguration _config;
    private readonly IFinancialYearContributionRepository _financialYearContributionRepository;

    public FinancialYearContributionService(IConfiguration config, IFinancialYearContributionRepository financialYearContributionRepository)
    {
        _config = config;
        _financialYearContributionRepository = financialYearContributionRepository;
    }

    
    public async Task<IEnumerable<FinancialYearContribution>> GetContributionByIdAsync(int id)
    {
        return await _financialYearContributionRepository.GetContributionByIdAsync(id);
        
    }

    public async Task AddContributionAsync(FinancialYearContribution contribution)
    {
        await _financialYearContributionRepository.AddContributionAsync(contribution);
    }
}
