﻿using Dapper;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using System.Linq;
using backend.Repositories;

namespace backend.Services;

public class RetirementGoalService : IRetirementGoalService
{
    private readonly IConfiguration _config;
    private readonly IRetirementGoalRepository _retirementGoalRepository;

    public RetirementGoalService(IConfiguration config, IRetirementGoalRepository retirementGoalRepository)
    {
        _config = config;
        _retirementGoalRepository = retirementGoalRepository;
    }

    
     
    public async Task<RetirementGoal> AddGoalAsync(RetirementGoal goal)
    {
        return await _retirementGoalRepository.AddGoalAsync(goal); // ✅ Ensure correct `Id` is returned
    }


    public async Task<IEnumerable<RetirementGoal>> GetGoalsByUserIdAsync(int UserId)
    {
        return await _retirementGoalRepository.GetGoalsByUserIdAsync(UserId);
    }
}
