using Dapper;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using backend.Models;
using System.Collections.Generic;
using System.Linq;
using backend.Repositories;
namespace backend.Services{
    public class UserProfileService : IUserProfileService
    {
        private readonly IConfiguration _config;
        private readonly IUserProfileRepository _userProfileRepository;

        public UserProfileService(IConfiguration config, IUserProfileRepository userProfileRepository)
        {
            _config = config;
            _userProfileRepository = userProfileRepository;
        }

        public async Task AddAsync(UserProfile user)
        {
            await _userProfileRepository.AddAsync(user);
        }

        public async Task<UserProfile?> LoginAsync(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                return null;
            }

            var user = await _userProfileRepository.LoginAsync(email, password);

            return user ?? null; 
        }


    }
}