using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using backend.Data;
using backend.Models;
using backend.Services;
using System.Net;
using Microsoft.Extensions.Logging;
using MySql.Data.MySqlClient;

namespace MyApp.Namespace
{
    [Route("api/[controller]")]
    [ApiController]
    public class RetirementGoalController : ControllerBase
    {
        private readonly IRetirementGoalService _service;
        private readonly ILogger<RetirementGoalController> _logger;

        public RetirementGoalController(IRetirementGoalService service, ILogger<RetirementGoalController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [HttpGet("{UserId}")]
        public async Task<IActionResult> GetGoals(int UserId)
        {
            if (UserId <= 0)
            {
                _logger.LogWarning("Invalid User ID provided: {UserId}", UserId);
                return BadRequest("Invalid User ID.");
            }

            try
            {
                var goals = await _service.GetGoalsByUserIdAsync(UserId);

                if (goals == null || !goals.Any())
                {
                    _logger.LogInformation("No retirement goals found for User ID: {UserId}", UserId);
                    return NotFound("No goals found for this user.");
                }

                _logger.LogInformation("Goals retrieved successfully for User ID: {UserId} - Data: {@Goals}", UserId, goals);
                return Ok(goals); // ✅ Log and verify correct ID is included
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving goals for User ID: {UserId}", UserId);
                return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while retrieving retirement goals.");
            }
        }


        [HttpPost]
        public async Task<IActionResult> AddGoal([FromBody] RetirementGoal goal)
        {
            if (goal == null)
            {
                _logger.LogWarning("Received null goal data.");
                return BadRequest(new { message = "Invalid goal data." });
            }

            try
            {
                var newGoal = await _service.AddGoalAsync(goal);

                if (newGoal == null || newGoal.Id == 0)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError, new { message = "Failed to create goal." });
                }

                _logger.LogInformation("Retirement goal added successfully for User ID: {UserId}", goal.UserId);
                return Ok(new { goal = newGoal});
            }
            catch (MySqlException ex)
            {
                _logger.LogError(ex, "Error adding retirement goal for User ID: {UserId}", goal.UserId);

                // Handle specific MySQL validation errors
                if (ex.Message.Contains("Error: Desired savings must be greater than current savings."))
                {
                    return BadRequest(new { message = "Desired savings must be greater than current savings." });
                }

                return StatusCode((int)HttpStatusCode.InternalServerError, new { message = "An error occurred while adding the retirement goal." });
            }
        }



    }
}
