using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using backend.Data;
using backend.Models;
using backend.Services;
using System.Net;
using Microsoft.Extensions.Logging;

namespace MyApp.Namespace
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserProgressController : ControllerBase
    {
        private readonly IUserProgressService _service;
        private readonly ILogger<UserProgressController> _logger;

        public UserProgressController(IUserProgressService service, ILogger<UserProgressController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [HttpGet("{GoalId}")]
        public async Task<IActionResult> GetProgress(int GoalId)
        {
            if (GoalId <= 0)
            {
                _logger.LogWarning("Invalid Goal ID provided: {GoalId}", GoalId);
                return BadRequest("Invalid Goal ID.");
            }

            try
            {
                var progress = await _service.GetUserProgressByGoalIdAsync(GoalId);

                if (progress == null || !progress.Any())
                {
                    _logger.LogInformation("No Progress found for the goal id: {GoalId}", GoalId);
                    return NotFound("No Progress Found");
                }

                _logger.LogInformation("Progress retrieved successfully for Goal ID: {GoalId} - Data: {@Progress}", GoalId, progress);
                return Ok(progress); 
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching progress for Goal ID: {GoalId}", GoalId);
                return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while retrieving progress.");
            }
        }
    }
}
