using Microsoft.AspNetCore.Http;
using backend.Data;
using backend.Models;
using backend.Services;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Microsoft.Extensions.Logging;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserProfileController : ControllerBase
    {
        private readonly IUserProfileService _service;
        private readonly ILogger<UserProfileController> _logger; 

        public UserProfileController(IUserProfileService service, ILogger<UserProfileController> logger)
        {
            _service = service;
            _logger = logger; 
        }

        [HttpPost] // api/UserProfile
        public async Task<ActionResult> Create(UserProfile profile)
        {
            if (profile == null)
            {
                _logger.LogWarning("Received null profile data."); 
                return BadRequest("Invalid profile data.");
            }

            try
            {
                await _service.AddAsync(profile);
                _logger.LogInformation("Profile created successfully for email: {Email}", profile.Email);
                return Ok("Profile created successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating profile for email: {Email}", profile?.Email);
                return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while creating the profile.");
            }
        }

        [HttpPost("login")] // api/UserProfile/login
        public async Task<IActionResult> Login([FromBody] LoginRequest login)
        {
            if (login == null)
            {
                _logger.LogWarning("Received null login request.");
                return BadRequest("Invalid login data.");
            }

            if (string.IsNullOrWhiteSpace(login.Email) || string.IsNullOrWhiteSpace(login.Password))
            {
                _logger.LogWarning("Received empty login credentials.");
                return BadRequest("Email and password are required.");
            }

            try
            {
                var user = await _service.LoginAsync(login.Email, login.Password);

                
                if (user == null)
                {
                    _logger.LogWarning("Invalid login attempt for email: {Email}", login.Email);
                    return Unauthorized("Wrong credentials. Please try again.");
                }

                _logger.LogInformation("User logged in successfully: {Email}", login.Email);
                return Ok(user);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing login request for email: {Email}", login.Email);
                return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while processing the login request.");
            }
        }       
    }
}