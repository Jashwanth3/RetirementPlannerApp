using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using backend.Services;
using backend.Models;
using System.Net;
using Microsoft.Extensions.Logging;

namespace backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FinancialYearContributionController : ControllerBase
    {
        private readonly IFinancialYearContributionService _service;
        private readonly ILogger<FinancialYearContributionController> _logger;

        public FinancialYearContributionController(IFinancialYearContributionService service, ILogger<FinancialYearContributionController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetContribution(int id)
        {
            if (id <= 0)
            {
                _logger.LogWarning("Invalid ID provided: {Id}", id);
                return BadRequest("Invalid ID.");
            }

            try
            {
                var contributions = await _service.GetContributionByIdAsync(id);

                if (contributions == null || !contributions.Any())
                {
                    _logger.LogInformation("No contributions found for ID: {Id}", id);
                    return NotFound("Contribution not found.");
                }

                _logger.LogInformation("Contributions retrieved successfully for ID: {Id}", id);
                return Ok(contributions);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving contributions for ID: {Id}", id);
                return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while retrieving contributions.");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddContribution([FromBody] FinancialYearContribution contribution)
        {
            if (contribution == null)
            {
                _logger.LogWarning("Received null contribution data.");
                return BadRequest("Invalid contribution data.");
            }

            if (contribution.GoalId <= 0 || contribution.ContributionMonth <= 0 || contribution.ContributionYear < 2024 || contribution.ContributionAmount <= 0)
            {
                _logger.LogWarning("Invalid contribution fields provided.");
                return BadRequest("All fields are required.");
            }

            if (contribution.ContributionMonth < 1 || contribution.ContributionMonth > 12)
            {
                _logger.LogWarning("Invalid contribution month provided: {Month}", contribution.ContributionMonth);
                return BadRequest("Contribution month must be between 1 and 12.");
            }

            try
            {
                await _service.AddContributionAsync(contribution);
                _logger.LogInformation("Contribution added successfully for Goal ID: {GoalId}", contribution.GoalId);
                return Ok(new { message = "Contribution added successfully!", status = 200 });
            }
            catch (InvalidOperationException ex) // ✅ Detects repository error properly
            {
                _logger.LogWarning(ex.Message);
                return Conflict(new { message = ex.Message }); // ✅ Returns 409 Conflict for duplicate entries
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding contribution for Goal ID: {GoalId}", contribution.GoalId);
                return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while adding the contribution.");
            }
        }

    }
}
