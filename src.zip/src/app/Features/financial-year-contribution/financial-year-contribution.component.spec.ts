import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialYearContributionComponent } from './financial-year-contribution.component';

describe('FinancialYearContributionComponent', () => {
  let component: FinancialYearContributionComponent;
  let fixture: ComponentFixture<FinancialYearContributionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FinancialYearContributionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FinancialYearContributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
