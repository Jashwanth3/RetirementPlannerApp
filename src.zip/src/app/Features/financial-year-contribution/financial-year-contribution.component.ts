import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FinancialYearContributionService } from '../../Services/FinancialYearContributionService/financial-year-contribution.service';
import { FinancialYearContribution } from '../../Models/FinancialYearContribution/financial-year-contribution.interface';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-financial-year-contribution',
  standalone: true,
  templateUrl: './financial-year-contribution.component.html',
  styleUrls: ['./financial-year-contribution.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class FinancialYearContributionComponent {
  @Input() goalId!: number; // ✅ Single goal now
  @Input() recommendedValue!: number;
  @Output() contributionSubmitted = new EventEmitter<FinancialYearContribution>();

  contributionForm: FormGroup;
  successMessage = '';
  errorMessage = '';

  constructor(private fb: FormBuilder, private financialContributionService: FinancialYearContributionService) {
    this.contributionForm = this.fb.group({
      contributionMonth: ['', [Validators.required, Validators.min(1), Validators.max(12)]],
      contributionYear: ['', [Validators.required, Validators.min(2024)]],
      contributionAmount: ['', [Validators.required, Validators.min(1)]]
    });
  }

  submitContribution() {
    if (this.contributionForm.invalid) {
      this.errorMessage = 'Please fill out all required fields correctly.';
      return;
    }

    const contributionData: FinancialYearContribution = { 
      ...this.contributionForm.value, 
      goalId: this.goalId 
    };

    this.financialContributionService.makeFinancialContribution(contributionData).subscribe({
      next: (submittedContribution) => {
        this.successMessage = 'Contribution added successfully!';
        this.errorMessage = '';
        this.contributionForm.reset();
        this.contributionSubmitted.emit(submittedContribution);
        
      },
      error: (error) => {
        console.error('Error submitting contribution:', error);
    
        // ✅ Check the HTTP status code
        if (error?.statusCode === 409) {  // 409 Conflict for duplicate entries
          this.errorMessage = 'Contribution for this month already exists.';
        } else {
          this.errorMessage = error?.message || 'Failed to submit financial contribution.';
        }
      }
    });
  }
}
