import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { UserProgressService } from '../../Services/UserProgressService/user-progress.service';
import { UserProgress } from '../../Models/UserProgress/user-progress';

@Component({
  selector: 'app-user-progress',
  standalone: true,
  templateUrl: './user-progress.component.html',
  styleUrls: ['./user-progress.component.css'],
  imports: [CommonModule] 
})
export class UserProgressComponent implements OnInit {
  @Input() goalId!: number;
  @Input() progressPercentage!: number;
  @Input() desiredSavings!: number;
  @Input() totalContributed!: number;
  @Output() progressLoaded = new EventEmitter<UserProgress>();

  userProgress: UserProgress | null = null;
  loading = false;
  errorMessage = '';

  constructor(private progressService: UserProgressService) {}

  ngOnInit() {
    if (this.goalId) {
      this.fetchUserProgress();
    }
  }

  fetchUserProgress() {
    this.loading = true;
    this.progressService.fetchUserProgress(this.goalId).subscribe({
      next: (progressRecord: UserProgress) => { 
        console.log("Fetched Progress Record:", progressRecord);
        this.userProgress = progressRecord; 
        this.progressLoaded.emit(this.userProgress);
        this.loading = false;
      },
      error: (err) => {
        console.error('Error fetching progress:', err);
        this.errorMessage = 'Failed to fetch user progress.';
        this.loading = false;
      }
    });
  }
  
  
}
