import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserProfileService } from '../../Services/UserProfileService/user-profile.service';
import { RetirementGoalService } from '../../Services/RetirementGoalService/retirement-goal.service';
import { UserProfile } from '../../Models/UserProfile/user-profile.interface';
import { RetirementGoal } from '../../Models/RetirementGoal/retirement-goal.interface';
import { UserProgress } from '../../Models/UserProgress/user-progress';
import { CommonModule } from '@angular/common';
import { CreateGoalComponent } from '../create-goal/create-goal.component';
import { FinancialYearContributionComponent } from '../financial-year-contribution/financial-year-contribution.component';
import { UserProgressComponent } from '../user-progress/user-progress.component';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  imports: [CommonModule, ReactiveFormsModule, CreateGoalComponent, FinancialYearContributionComponent, UserProgressComponent]
})
export class DashboardComponent implements OnInit {
  userProfile!: UserProfile | null; 
  userGoal!: RetirementGoal | null ; 
  userProgressRecord!: UserProgress | null;
  hasGoal = false;
  showUserModal = false;
  showCreateGoal = false; 
  showContribution = false; 
  showUserProgressModal = false;
  progressPercentage = 0;
  recommendedValue = 0;
  totalContributed = 0;

  constructor(
    private userProfileService: UserProfileService, 
    private retirementGoalService: RetirementGoalService,
    private router: Router, 
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const parsedProfile = params['userProfile'] ? JSON.parse(params['userProfile']) : null;
      this.userProfile = parsedProfile ?? null;

      if (!this.userProfile?.id) {
        
        this.router.navigate(['/login']);
      } else {
        console.log("User Logged In:", this.userProfile.userName);
        console.log("User ID:", this.userProfile.id);
        this.loadUserGoal(this.userProfile.id);
      }
    });
  }
  loadUserGoal(userId: number) {
    this.userProfileService.fetchUserGoal(userId).subscribe({
      next: (goalResponse: RetirementGoal | null | RetirementGoal[]) => { 
        if (Array.isArray(goalResponse) && goalResponse.length > 0) { 
          this.userGoal = goalResponse[0];
        } else if (goalResponse && !Array.isArray(goalResponse)) {
          this.userGoal = goalResponse; 
        } else {
          this.userGoal = null;
        }
  
        this.hasGoal = !!this.userGoal;
        console.log("User Goal Assigned:", this.userGoal);
      },
      error: (err) => {
        console.error("Error fetching goal:", err);
        this.userGoal = null;
        this.hasGoal = false;
      }
    });
  }
  
  

  toggleContribution() { 
    if (!this.userGoal) return;
    this.recommendedValue = this.userGoal.recommendedValue ?? 0;
    console.log(`Opening Contribution Modal, Recommended Value: ${this.recommendedValue}`);
    this.showContribution = !this.showContribution;

  }

  closeContributionModal() {
    this.showContribution = false;
  }

  handleGoalCreated(createdGoal: any) { 
    if (createdGoal && createdGoal.goal) {
      console.log("New goal created:", createdGoal.goal); 
      this.userGoal = createdGoal.goal;  
      this.hasGoal = true;
    }
    this.showCreateGoal = false;
  }
  

  
  
  handleUserProgress(progressRecord: UserProgress | UserProgress[]) {
    
  
    const progressData = Array.isArray(progressRecord) ? progressRecord[0] : progressRecord;
  
    if (!progressData || !this.userGoal) {
      
      return;
    }
  
    if (progressData?.totalContributed !== undefined && this.userGoal?.desiredSavings !== undefined) {
      if (this.userGoal.desiredSavings > 0) {
        this.progressPercentage = Number(((progressData.totalContributed / this.userGoal.desiredSavings) * 100).toFixed(2));
        this.totalContributed = progressData.totalContributed;
        
        
      } else {
        console.error("Error: desiredSavings is 0 or undefined.");
        this.progressPercentage = 0;
      }
    } else {
      this.progressPercentage = 0;
    }
  
    console.log(`Updated Progress Percentage: ${this.progressPercentage}%`);
  }
  
  
  
  

  toggleUserProgress() {
    if (!this.userGoal) {
      console.error("Goal is required.");
      return;
    }
    this.showUserProgressModal = !this.showUserProgressModal;
  }

  logout() {
    this.router.navigate(['/login']);
  }
}
