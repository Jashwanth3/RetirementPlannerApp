import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../Services/AuthService/auth.service';
import { LoginRequest } from '../../Models/LoginRequest/login-request.interface';
import { UserProfile } from '../../Models/UserProfile/user-profile.interface'; 
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  email = '';
  password = '';
  errorMessage = '';
  successMessage = '';

  constructor(private authService: AuthService, private router: Router) {}

  login() {
    this.errorMessage = ''; 
    this.successMessage = ''; 

    const loginRequest: LoginRequest = { email: this.email, password: this.password };

    this.authService.login(loginRequest).subscribe({
      next: (userProfile: UserProfile) => {
        console.log('User Logged In:', userProfile);
        localStorage.setItem('userProfile', JSON.stringify(userProfile)); 

        if (!userProfile.id) {
          console.error('Missing User ID in response.');
          this.errorMessage = 'Login failed. No user ID received.';
          return;
        }

        this.successMessage = 'Login successful! Redirecting...';
        
        this.router.navigate(['/dashboard'], { queryParams: { userProfile: JSON.stringify(userProfile) } });
      },
      error: (err) => {
        console.error('Login Error:', err);
        this.errorMessage = err.message || 'Login failed.';
      }
    });
  }
}
