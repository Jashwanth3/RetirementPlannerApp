import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { RetirementGoalService } from '../../Services/RetirementGoalService/retirement-goal.service';
import { RetirementGoal } from '../../Models/RetirementGoal/retirement-goal.interface';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-create-goal',
  standalone: true,
  templateUrl: './create-goal.component.html',
  styleUrls: ['./create-goal.component.css'],
  imports: [CommonModule, ReactiveFormsModule]
})
export class CreateGoalComponent {
  @Input() userId!: number; 
  @Input() currAge!: number;
  @Output() goalCreated = new EventEmitter<RetirementGoal>(); 

  goalForm: FormGroup;
  successMessage = '';
  errorMessage = '';

  constructor(private fb: FormBuilder, private retirementGoalService: RetirementGoalService) {
    this.goalForm = this.fb.group({
      desiredSavings: ['', [Validators.required, Validators.min(1000)]], 
      retirementAge: ['', [Validators.required, Validators.min(50), Validators.max(80)]], 
      currSavings: ['', [Validators.required, Validators.min(0)]], 
      recommendedValue: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
    },{
    validators: this.validateCurrentSavings
    });

    this.goalForm.valueChanges.subscribe(() => {
      this.calculateRecommendedValue();
    });
  }

  validateCurrentSavings(form: AbstractControl) {
    const desiredSavings = form.get('desiredSavings')?.value;
    const currSavings = form.get('currSavings')?.value;
    
    return currSavings >= desiredSavings ? { savingsInvalid: true } : null;
  }

  submitForm() {
    if (this.goalForm.invalid) {
      this.errorMessage = 'Please fill out all required fields correctly.';
      return;
    }

    const retirementGoal: RetirementGoal = { 
      ...this.goalForm.value, 
      userId: this.userId 
    };

    this.retirementGoalService.createRetirementGoal(retirementGoal).subscribe({
      next: (createdGoal: RetirementGoal) => { 
        console.log("API returned goal:", createdGoal); 
        this.goalCreated.emit(createdGoal); 
      },
      error: (error) => {
        console.error("API Error:", error);
      }
    });
    
  }

  calculateRecommendedValue() {
    const { desiredSavings, retirementAge, currSavings } = this.goalForm.value;

    if (desiredSavings && retirementAge && currSavings !== undefined) {
      const yearsUntilRetirement = retirementAge - this.currAge;
      
      if (yearsUntilRetirement > 0) {
        const remainingSavingsNeeded = desiredSavings - currSavings;
        const recommendedValue = remainingSavingsNeeded / (yearsUntilRetirement * 12);
        this.goalForm.get('recommendedValue')?.setValue(Number(recommendedValue.toFixed(2)), { emitEvent: false });

      } else {
        this.goalForm.get('recommendedValue')?.setValue('0.00', { emitEvent: false });
      }
    }
  }
}
