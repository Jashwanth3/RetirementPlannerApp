import { Routes } from '@angular/router';
import { provideRouter } from '@angular/router';
import { LoginComponent } from '../Features/login/login.component';
import { DashboardComponent } from '../Features/dashboard/dashboard.component';
import { CreateGoalComponent } from '../Features/create-goal/create-goal.component';
import { FinancialYearContributionComponent } from '../Features/financial-year-contribution/financial-year-contribution.component';
export const routes: Routes = [
  
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent }, 
  { path: 'create-goal', component: CreateGoalComponent },
  { path: 'financial-year-contribution', component:FinancialYearContributionComponent}
];



export const appRouter = provideRouter(routes);
