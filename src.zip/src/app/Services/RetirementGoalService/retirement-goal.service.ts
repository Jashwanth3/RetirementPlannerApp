import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { RetirementGoal } from '../../Models/RetirementGoal/retirement-goal.interface';

@Injectable({
  providedIn: 'root'
})
export class RetirementGoalService {
  private apiUrl = 'http://localhost:5225/api/RetirementGoal';

  constructor(private http: HttpClient) {}

  createRetirementGoal(goal: RetirementGoal): Observable<RetirementGoal> { 
    return this.http.post<RetirementGoal>(this.apiUrl, goal).pipe(
      catchError(error => {
        console.error('Error creating retirement goal:', error);
        return throwError(() => new Error('Failed to create retirement goal.'));
      })
    );
  }
}
