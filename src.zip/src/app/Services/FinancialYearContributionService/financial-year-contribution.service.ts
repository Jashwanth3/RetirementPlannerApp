import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { FinancialYearContribution } from '../../Models/FinancialYearContribution/financial-year-contribution.interface';

@Injectable({
  providedIn: 'root'
})
export class FinancialYearContributionService {
  private apiUrl = 'http://localhost:5225/api/FinancialYearContribution';

  constructor(private http: HttpClient) {}

  makeFinancialContribution(contribution: FinancialYearContribution): Observable<FinancialYearContribution> {
    return this.http.post<FinancialYearContribution>(this.apiUrl, contribution).pipe(
      catchError(error => {
        console.error('Error adding financial contribution:', error);
  
        // ✅ Extract HTTP Status Code & Message
        const statusCode = error?.status;
        const errorMessage = error?.error?.message || 'Failed to add financial contribution.';
  
        return throwError(() => ({ statusCode, message: errorMessage }));
      })
    );
  }
  
}
