import { TestBed } from '@angular/core/testing';

import { FinancialYearContributionService } from './financial-year-contribution.service';

describe('FinancialYearContributionService', () => {
  let service: FinancialYearContributionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FinancialYearContributionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
