import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserProfile } from '../../Models/UserProfile/user-profile.interface';
import { RetirementGoal } from '../../Models/RetirementGoal/retirement-goal.interface';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {
  private apiUrl = 'http://localhost:5225/api/RetirementGoal'; // API endpoint for user profile

  constructor(private http: HttpClient) {}

  

  fetchUserGoal(userId: number): Observable<RetirementGoal | null> {
    return this.http.get<RetirementGoal>(`${this.apiUrl}/${userId}`).pipe(
      catchError(error => {
        console.error('Error fetching user goal:', error);
        return throwError(() => new Error('Failed to fetch user goal.'));
      })
    );
  }
}
