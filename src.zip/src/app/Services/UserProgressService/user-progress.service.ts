import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserProgress } from '../../Models/UserProgress/user-progress';

@Injectable({
  providedIn: 'root'
})
export class UserProgressService {
  private apiUrl = 'http://localhost:5225/api/UserProgress';

  constructor(private http: HttpClient) {}

  fetchUserProgress(goalId: number): Observable<UserProgress> {
    return this.http.get<UserProgress>(`${this.apiUrl}/${goalId}`).pipe(
      catchError(error => {
        console.error('Error fetching user progress:', error);
        return throwError(() => new Error('Failed to fetch user progress.'));
      })
    );
  }
}
