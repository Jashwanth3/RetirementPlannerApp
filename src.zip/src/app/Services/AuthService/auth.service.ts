import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { LoginRequest } from '../../Models/LoginRequest/login-request.interface';
import { UserProfile } from '../../Models/UserProfile/user-profile.interface';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:5225/api/UserProfile/Login'; // ✅ API endpoint for login

  constructor(private http: HttpClient) {}

  login(request: LoginRequest): Observable<UserProfile> {
    return this.http.post<UserProfile>(this.apiUrl, request).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error('Login Error:', error);

        let errorMessage = 'An error occurred while logging in.';
        
        if (error.error) {
          if (typeof error.error === 'string') {
            errorMessage = error.error; 
          } else if (error.error?.message) {
            errorMessage = error.error.message; 
          }
        }

        return throwError(() => new Error(errorMessage));
      })
    );
  }
}
