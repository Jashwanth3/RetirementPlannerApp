import { LoginRequest } from './login-request.interface';

describe('LoginRequest', () => {
  it('should create a valid login request object', () => {
    const loginRequest: LoginRequest = {
      email: 'user@example.com',
      password: 'securepassword123'
    };

    expect(loginRequest).toBeTruthy();
    expect(loginRequest.email).toContain('@');
    expect(loginRequest.password).toBeTruthy();
  });
});

