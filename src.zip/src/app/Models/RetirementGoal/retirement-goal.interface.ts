export interface RetirementGoal {
  id: number;
  userId: number;
  desiredSavings: number;
  retirementAge: number;
  currSavings: number;
  recommendedValue: number; // Optional property
}

