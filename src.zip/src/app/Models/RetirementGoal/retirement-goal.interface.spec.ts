import { RetirementGoal } from './retirement-goal.interface';

describe('RetirementGoal', () => {
  it('should create a valid retirement goal object', () => {
    const retirementGoal: RetirementGoal = {
      id: 1,
      userId: 101,
      desiredSavings: 500000,
      retirementAge: 60,
      currSavings: 100000,
      recommendedValue: 450000
    };

    expect(retirementGoal).toBeDefined();
    expect(retirementGoal.retirementAge).toBeGreaterThan(30);
    expect(retirementGoal.desiredSavings).toBeGreaterThan(retirementGoal.currSavings);
  });
});
