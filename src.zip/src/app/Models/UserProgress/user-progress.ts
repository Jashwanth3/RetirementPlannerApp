export interface UserProgress {
    UserProgress: UserProgress | null;
    id : number,
    goalId : number,
    totalContributed : number
}
