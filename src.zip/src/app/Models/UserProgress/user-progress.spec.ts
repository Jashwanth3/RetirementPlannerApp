import { UserProgress } from './user-progress';

describe('UserProgress', () => {
  it('should create a valid UserProgress object', () => {
    const progress: UserProgress = {
      id: 1,
      goalId: 100,
      totalContributed: 50
    };
    expect(progress).toBeTruthy();
  });
});
