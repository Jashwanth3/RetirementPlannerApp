export interface FinancialYearContribution {
  id: number;
  goalId: number;
  contributionMonth: number;
  contributionYear: number;
  contributionAmount: number;
}

