import { FinancialYearContribution } from './financial-year-contribution.interface';

describe('FinancialYearContribution', () => {
  it('should create a valid financial year contribution object', () => {
    const contribution: FinancialYearContribution = {
      id: 1,
      goalId: 101,
      contributionMonth: 5,
      contributionYear: 2025,
      contributionAmount: 2000
    };

    expect(contribution).toBeTruthy();
    expect(contribution.contributionYear).toBeGreaterThan(2000);
    expect(contribution.contributionAmount).toBeGreaterThan(0);
  });
});
