import { UserProfile } from './user-profile.interface';

describe('UserProfile', () => {
  it('should create a valid user profile object', () => {
    const userProfile: UserProfile = {
      id: 1,
      firstName: 'John',
      lastName: 'Doe',
      userName: 'johndoe',
      currAge: 30,
      email: 'john.doe@example.com',
      password: 'securepassword123'
    };

    expect(userProfile).toBeTruthy();
  });
});

