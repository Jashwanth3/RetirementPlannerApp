export interface UserProfile {
  id: number;
  firstName: string;
  lastName: string;
  userName: string;
  currAge: number;
  email: string;
  password: string;
}

