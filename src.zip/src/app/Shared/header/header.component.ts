import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // ✅ Required for *ngIf
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  userProfile: any = null; // ✅ Stores user data
  showUserModal: boolean = false; // ✅ Used for user details modal

  constructor(private router: Router) {
    // ✅ Load user profile if available
    const storedProfile = localStorage.getItem('userProfile');
    if (storedProfile) {
      this.userProfile = JSON.parse(storedProfile);
    }
  }

  showUserDetails() {
  console.log('User details button clicked!'); // ✅ Debugging log
  this.showUserModal = true; // ✅ Open modal
}

  closeUserDetails() {
    this.showUserModal = false; // ✅ Close user details modal
  }

  logout() {
    localStorage.removeItem('userProfile'); // ✅ Clear stored user data
    this.router.navigate(['/login']); // ✅ Redirect to login page
  }
}
