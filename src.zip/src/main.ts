import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { AppComponent } from './app/app/app.component';
import { appRouter } from './app/app/app.routes';

bootstrapApplication(AppComponent,  {
  providers: [appRouter, provideHttpClient()],
}).catch(err => console.error(err));
